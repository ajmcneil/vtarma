## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(tscopula)
library(stats4)

## ---- fig.show='hold', fig.width = 6, fig.height = 3, dev.args =list(pointsize=9)----
set.seed(13)
data1 <- 0.5 + 2*arima.sim(list(ar =0.95, ma =-0.85), 1000)
ts.plot(data1)

## -----------------------------------------------------------------------------
copspec <- armacopula(pars = list(ar =0.01, ma =0.01))
margspec <- margin("norm")
fullspec <- tscm(copspec, margspec)
modfit <- fit(fullspec, data1, method = "full")
modfit

## ---- fig.show='hold', dev.args =list(pointsize=9)----------------------------
plot(modfit, plotoption = 1)
plot(modfit, plotoption = 2)
plot(modfit, plotoption = 3)
plot(modfit, plotoption = 4)
plot(modfit, plotoption = 5)
plot(modfit, plottype = "margin")

## -----------------------------------------------------------------------------
copmod <- dvinecopula(
  family = c("Clayton","t", "Frank", "Gaussian"),
  pars = list(0.7, c(0.2,5), 1, 0.1),
  rotation = c(180,0, 0,0)
)
copmod
vcopmod <- vtscopula(copmod,
                     Vtransform = V2p(delta = 0.5, kappa = 2))
margmod <- margin("slaplace",
                  pars = c(mu = 1, scale = 2, gamma = 0.7))
tscmmod <- tscm(vcopmod, margmod)
tscmmod

## ---- fig.show='hold', fig.width = 6, fig.height = 3, dev.args =list(pointsize=9)----
set.seed(29)
data2 <- sim(tscmmod, n= 2000)
hist(data2)
ts.plot(data2)

## -----------------------------------------------------------------------------
margfit <- fit(margmod, data2)

## -----------------------------------------------------------------------------
tscmfit_step <- fit(tscmmod, data2)
tscmfit_step
coef(tscmfit_step)
coef(tscmmod)

## -----------------------------------------------------------------------------
tscmfit_full <- fit(tscmfit_step, data2, method = "full")
tscmfit_full

## -----------------------------------------------------------------------------
AIC(margfit, tscmfit_step, tscmfit_full)

## ---- fig.show='hold', dev.args =list(pointsize=9)----------------------------
plot(tscmfit_full, plotoption = 1)
plot(tscmfit_full, plotoption = 2)

## ---- fig.show='hold', dev.args =list(pointsize=9)----------------------------
plot(tscmfit_full, plottype = "margin")

## ---- fig.show='hold', dev.args =list(pointsize=9)----------------------------
plot(tscmfit_full, plottype = "vtransform")
plot(tscmfit_full, plottype = "volprofile")

## ---- fig.show='hold', dev.args =list(pointsize=9)----------------------------
plot(tscmfit_full, plottype = "volproxy")
plot(tscmfit_full, plotoption = 2, plottype = "volproxy")


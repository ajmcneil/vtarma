## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(tscopula)

## -----------------------------------------------------------------------------
copmod <- dvinecopula(
  family = c("Clayton","t", "Frank", "Gaussian"),
  pars = list(1.2, c(0.4,5), 2, 0.15),
  rotation = c(180,0, 0,0)
)
copmod

## ---- fig.show='hold', fig.width = 6, fig.height = 3, dev.args =list(pointsize=9)----
set.seed(29)
data1 <- sim(copmod, n = 2000)
hist(data1)
ts.plot(data1)

## -----------------------------------------------------------------------------
copspec <- dvinecopula(
  family = c("Clayton","t", "Frank", "Gaussian"),
  pars = list(0.5, c(0,10), 1, 0),
  rotation = c(180, 0, 0, 0)
)
copfit <- fit(copspec, data1, tsoptions = list(hessian = TRUE))
copfit
coef(copfit)
coef(copmod)

## ---- fig.show='hold', dev.args =list(pointsize=9)----------------------------
plot(copfit, plotoption = 1)
plot(copfit, plotoption = 2)

## ---- fig.show='hold', fig.width = 6, fig.height = 6, dev.args =list(pointsize=9)----
plot(copfit, plotoption = 3)

## -----------------------------------------------------------------------------
vcopmod <- vtscopula(copmod,
  Vtransform = V2p(delta = 0.55, kappa = 1.2)
)
vcopmod

## ---- fig.show='hold', fig.width = 6, fig.height = 3, dev.args =list(pointsize=9)----
set.seed(19)
data2 <- sim(vcopmod, n = 2000)
hist(data2)
ts.plot(data2)

## -----------------------------------------------------------------------------
vcopspec <- vtscopula(copspec, V2p())
vcopfit <- fit(vcopspec, data2, 
               tsoptions = list(hessian = TRUE),
               control = list(maxit = 3000))
vcopfit
coef(vcopfit)
coef(vcopmod)

## ---- fig.show='hold', fig.width = 6, fig.height = 3, dev.args =list(pointsize=9)----
plot(vcopfit, plottype = "vtransform")
plot(vcopfit, plotoption = 2)

## -----------------------------------------------------------------------------
data2b <- sim(vcopfit, 2000)
ts.plot(data2b)


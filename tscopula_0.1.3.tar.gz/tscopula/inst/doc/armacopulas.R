## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(tscopula)

## -----------------------------------------------------------------------------
ar1 <- armacopula(list(ar = 0.7))
ar1

## ---- fig.show='hold', fig.width = 6, fig.height = 3, dev.args =list(pointsize=9)----
set.seed(13)
data1 <- sim(ar1, 1000)
ts.plot(data1)

## -----------------------------------------------------------------------------
ar1spec <- armacopula(list(ar = 0))
ar1fit <- fit(ar1spec, data1)
ar1fit

## ---- fig.show='hold', fig.width = 6, fig.height = 3, dev.args =list(pointsize=9)----
arma11 <- armacopula(list(ar = 0.95, ma = -0.85))
data2 <- sim(arma11, 1000)
ts.plot(data2)

arma11spec <- armacopula(list(ar = 0.1, ma = 0.1))
arma11fit <- fit(arma11spec, data2, tsoptions = list(hessian = TRUE))
arma11fit

## ---- fig.show='hold'---------------------------------------------------------
coef(arma11fit)

plot(arma11fit, plotoption = 1)
plot(arma11fit, plotoption = 2)
plot(arma11fit, plotoption = 3)
plot(arma11fit, plotoption = 4)
plot(arma11fit, plotoption = 5)

## -----------------------------------------------------------------------------
head(kfilter(arma11fit@tscopula, data2))

## ---- fig.show='hold', fig.width = 6, fig.height = 3, dev.args =list(pointsize=9)----
vtar1 <- vtscopula(armacopula(list(ar = 0.7)), Vtransform = Vlinear(0.5))
set.seed(19)
data3 <- sim(vtar1, 2000)
ts.plot(data3)

vtar1spec <- vtscopula(ar1spec, Vtransform = Vlinear())
vtar1fit <- fit(vtar1spec, data3)
vtar1fit

## ---- fig.show='hold', dev.args =list(pointsize=9)----------------------------
vtarma11 <- vtscopula(armacopula(list(ar = 0.95, ma = -0.85)),
  Vtransform = Vlinear(delta = 0.55))
set.seed(19)
data4 <- sim(vtarma11, 2000)
ts.plot(data4)

vtarma11spec <- vtscopula(arma11spec, Vtransform = Vlinear())
vtarma11fit <- fit(vtarma11spec, data4)
vtarma11fit

plot(vtarma11fit, plottype = "vtransform")
plot(vtarma11fit, plotoption = 1)
plot(vtarma11fit, plotoption = 2)
plot(vtarma11fit, plotoption = 3)
plot(vtarma11fit, plotoption = 4)
plot(vtarma11fit, plotoption = 5)

## -----------------------------------------------------------------------------
vt2arma11 <- vtscopula(armacopula(list(ar = 0.95, ma = -0.85)),
  Vtransform = V2p(delta = 0.55, kappa = 0.8))
set.seed(17)
data5 <- sim(vt2arma11, n = 5000)

vt2arma11spec <- vtscopula(arma11spec, Vtransform = V2p())
vt2arma11fit <- fit(vt2arma11spec, data5)
vt2arma11fit

## -----------------------------------------------------------------------------
data5b <- sim(vt2arma11fit, 1000)
ts.plot(data5b)

## ---- fig.show='hold', dev.args =list(pointsize=9)----------------------------
profilefulcrum(data5, tscopula = vt2arma11spec, locations = seq(from = 0, to = 1, length = 21))
abline(v = 0.55)


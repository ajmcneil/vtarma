#' Full models
#'
#' Class of objects for composite time series models consisting
#' of stationary copula processes and marginal distributions.
#'
#' @slot tscopula an object of class \linkS4class{tscopula}.
#' @slot margin an object of class \linkS4class{margin}.
#'
#' @export
#'
setClass("tscm",
  slots = list(
    tscopula = "tscopula",
    margin = "margin"
  )
)

#' Show Method for tscm Class
#'
#' @param object an object of class \linkS4class{tscm}.
#'
#' @return A summary of an object of class \linkS4class{tscm}.
#' @export
#'
setMethod("show", "tscm", function(object) {
  cat("object class: ", is(object)[[1]], "\n", sep = "")
  cat("_______ \n")
  cat("MARGIN: \n")
  show(object@margin)
  cat("_______\n")
  cat("COPULA: \n")
  show(object@tscopula)
  if (is(object, "tscmfit")) {
    ests <- object@fit$par
    if ("skeleton" %in% names(attributes(ests))) {
      attributes(ests)$skeleton <- NULL
    }
    if (is.element("hessian", names(object@fit))) {
      ses <- safe_ses(object@fit$hessian)
      ests <- rbind(ests, ses)
      dimnames(ests)[[1]] <- c("par", "se")
    }
    cat("_________________________\n")
    cat("summary of all estimates:\n")
    print(ests)
    cat("convergence status:", object@fit$convergence, ", log-likelihood:",
      -object@fit$value, "\n",
      sep = " "
    )
  }
})

#' Coefficient Method for tscm Class
#'
#' @param object an object of class \linkS4class{tscm}.
#'
#' @return Vector of coefficients of model.
#' @export
#'
setMethod("coef", "tscm", function(object) {
  c(coef(object@tscopula), coef(object@margin))
})

#' Constructor Function for time series
#'
#' @param tscopula an object of class \linkS4class{tscopula}.
#' @param margin an object of class \linkS4class{margin}.
#'
#' @return An object of class \linkS4class{tscm}.
#' @export
#'
#' @examples
#' tscm(dvinecopula(family = "gauss", pars = 0.5), margin("doubleweibull"))
tscm <- function(tscopula, margin = new("margin", name = "unif")) {
  if (is(tscopula, "tscopulafit")) {
    tscopula <- tscopula@tscopula
  }
  if (is(margin, "marginfit")) {
    margin <- margin@margin
  }
  new("tscm",
    tscopula = tscopula,
    margin = margin
  )
}

#' Simulation Method for tscm class
#'
#' @param x an object of class \linkS4class{tscm}.
#' @param n length of realization.
#'
#' @return A realization of the time series of length n
#' @export
#'
#' @examples
#' mod <- tscm(dvinecopula(family = "gauss", pars = 0.5), margin("doubleweibull"))
#' sim(mod)
setMethod(
  "sim",
  c(x = "tscm"),
  function(x, n = 1000) {
    Utilde <- sim(x@tscopula, n)
    qmarg(x@margin, Utilde)
  }
)

#' Fitted tscm Model
#'
#' Class of objects for fitted \linkS4class{tscm} models.
#'
#' @slot tscopula an object of class \linkS4class{tscopula}.
#' @slot margin an object of class \linkS4class{margin}.
#' @slot data a vector or time series of data to which process has been fitted.
#' @slot fit a list containing details of the fit.
#'
#' @export
#'
setClass(
  "tscmfit",
  contains = "tscm",
  slots = list(
    tscopula = "tscopula",
    margin = "margin",
    data = "ANY",
    fit = "list"
  )
)

#' Fit Method for tscm Class
#'
#' @param x an object of class \linkS4class{tscm}.
#' @param y a vector or time series of data.
#' @param tsoptions a list of parameters passed to fitting.
#' @param control list of control parameters to be passed to the
#' \code{\link[stats]{optim}} function.
#' @param method character string specifying method.
#'
#'
#' @return An object of class \linkS4class{tscmfit}.
#' @export
#'
#' @examples
#' mod <- tscm(dvinecopula(family = "gauss", pars = 0.5), margin("doubleweibull"))
#' y <- sim(mod)
#' fit(mod, y)
setMethod(
  "fit", c(x = "tscm", y = "ANY"),
  function(x,
           y,
           tsoptions = list(),
           control = list(
             warn.1d.NelderMead = FALSE,
             trace = FALSE,
             maxit = 5000
           ),
           method = "IFM") {
    defaults <- list(hessian = FALSE, method = "Nelder-Mead", fulcrum = NA, avoidzero = TRUE)
    tsoptions <- setoptions(tsoptions, defaults)
    if (is(x, "tscmfit")) {
      tscopula <- x@tscopula
      margin <- x@margin
      if (is(tscopula, "tscopulafit")) {
        tscopula <- tscopula@tscopula
      }
      if (is(margin, "marginfit")) {
        margin <- margin@margin
      }
      x <- new("tscm", tscopula = tscopula, margin = margin)
    }
    if ((method == "full") & is(x@tscopula, "tscopulaU")) {
      method <- paste(method, "A", sep = "")
    }
    if ((method == "full") & is(x@tscopula, "vtscopula")) {
      method <- paste(method, "B", sep = "")
    }
    switch(method,
      empirical = fitEDF(x, y, tsoptions, control),
      IFM = fitSTEPS(x, y, tsoptions, control),
      fullA = fitFULLa(x, y, tsoptions, control),
      fullB = fitFULLb(x, y, tsoptions, control),
      stop("Not a known method")
    )
  }
)

#' Fit tscm Using Empirical Distribution Function
#'
#' @param x an object of class \linkS4class{tscm}.
#' @param y a vector or time series of data.
#' @param tsoptions a list of parameters passed to fitting.
#' This differs according to the class of x.
#' @param control list of control parameters to be passed to the
#' \code{\link[stats]{optim}} function.
#'
#' @return An object of class \linkS4class{tscmfit}.
#' @keywords internal
#'
fitEDF <- function(x, y, tsoptions, control) {
  U <- strank(as.numeric(y))
  copfit <- fit(x@tscopula, U, tsoptions, control)
  new("tscmfit",
    tscopula = copfit@tscopula,
    margin = new("margin", name = "edf"),
    data = y,
    fit = copfit@fit
  )
}

#' Fit tscm in Two Steps
#'
#' @param x an object of class \linkS4class{tscm}.
#' @param y a vector or time series of data.
#' @param tsoptions a list of parameters passed to fitting.
#' This differs according to the class of x.
#' @param control list of control parameters to be passed to the
#' \code{\link[stats]{optim}} function.
#'
#' @return An object of class \linkS4class{tscmfit}.
#' @keywords internal
#'
fitSTEPS <- function(x, y, tsoptions, control) {
  margfit <- fit(x@margin, y, tsoptions = tsoptions, control = control)
  U <- pmarg(margfit, y)
  copfit <- fit(x@tscopula, U, tsoptions = tsoptions, control = control)
  combinedfit <- list()
  names(margfit@fit$par) <- paste("margin.", names(margfit@fit$par), sep = "")
  combinedfit$par <- c(copfit@fit$par, margfit@fit$par)
  if ("hessian" %in% names(tsoptions)) {
    if (tsoptions$hessian) {
      combinedfit$hessian <- Matrix::bdiag(margfit@fit$hessian, copfit@fit$hessian)
    }
  }
  combinedfit$convergence <- sum(copfit@fit$convergence, margfit@fit$convergence)
  combinedfit$value <- sum(copfit@fit$value, margfit@fit$value)
  new("tscmfit",
    tscopula = copfit@tscopula,
    margin = margfit@margin,
    data = y,
    fit = combinedfit
  )
}

#' Fit tscm Jointly
#'
#' @param x an object of class \linkS4class{tscm}.
#' @param y a vector or time series of data.
#' @param tsoptions list of variables
#' @param control list of control parameters to be passed to the
#' \code{\link[stats]{optim}} function.
#'
#' @return An object of class \linkS4class{tscmfit}.
#' @keywords internal
#'
fitFULLa <- function(x, y, tsoptions, control) {
  dens <- eval(parse(text = paste("d", x@margin@name, sep = "")))
  cdf <- eval(parse(text = paste("p", x@margin@name, sep = "")))
  parlist <- x@tscopula@pars
  parlist$margin <- x@margin@pars
  theta <- tsunlist(parlist, tsoptions$fulcrum)
  fit <- optim(
    par = theta,
    fn = tsc_objectivea,
    modelspec = x@tscopula@modelspec,
    modeltype = is(x@tscopula)[[1]],
    dens = dens,
    cdf = cdf,
    y = as.numeric(y),
    method = tsoptions$method,
    hessian = tsoptions$hessian,
    control = control
  )
  newpars <- tsrelist(fit$par, fulcrum = tsoptions$fulcrum)
  x@margin@pars <- newpars$margin
  x@tscopula@pars <- newpars[names(newpars) != "margin"]
  new("tscmfit", tscopula = x@tscopula, margin = x@margin, data = y, fit = fit)
}



#' Objective Function for Full of tscopula plus margin Model
#'
#' @param theta vector of parameter values
#' @param modelspec list containing model specification
#' @param modeltype character string giving type of model
#' @param dens marginal density function
#' @param cdf marginal cdf
#' @param y vector of data values
#'
#' @return Value of objective function at parameters.
#' @keywords internal
#'
tsc_objectivea <-
  function(theta, modelspec, modeltype, dens, cdf, y) {
    margpars <- theta[substring(names(theta), 1, 6) == "margin"]
    nonmargpars <- theta[substring(names(theta), 1, 6) != "margin"]
    names(margpars) <- substring(names(margpars), 8)
    dx <- do.call(dens, append(as.list(margpars), list(x = y, log = TRUE)))
    termA <- -sum(dx)
    if (is.na(termA)) {
      return(NA)
    }
    U <- do.call(cdf, append(margpars, list(q = y)))
    objective <- eval(parse(text = paste(modeltype, "_objective", sep = "")))
    termBC <-
      objective(nonmargpars, modelspec, U)
    return(termA + termBC)
  }

#' Convert tscopula Object to tscm Object
#'
#' @param from a \linkS4class{tscopula} object.
#' @param to a \linkS4class{tscm} object.
#' @param strict logical variable stating whether strict coercion should be enforced.
#'
#' @return A \linkS4class{tscm} object.
#' @export
#'
setMethod(
  "coerce", c(from = "tscopula", to = "tscm"),
  function(from, to = "tsc", strict = TRUE) {
    new("tscm", tscopula = from, margin = new("margin", name = "unif"))
  }
)

#' Convert tscopulafit Object to be tscmfit Object
#'
#' @param from a \linkS4class{tscopulafit} object.
#' @param to a \linkS4class{tscmfit} object.
#' @param strict logical variable stating whether strict coercion should be enforced.
#'
#' @return A \linkS4class{tscmfit} object.
#' @export
#'
setMethod(
  "coerce", c(from = "tscopulafit", to = "tscmfit"),
  function(from, to = "tscmfit", strict = TRUE) {
    new("tscmfit",
      tscopula = from,
      margin = new("margin", name = "unif"),
      data = from@data,
      fit = from@fit
    )
  }
)

#' logLik Method for tscmfit Class
#'
#' @param object an object of class \linkS4class{tscmfit}.
#'
#' @return An object of class logLik.
#' @export
#'
setMethod("logLik", "tscmfit", function(object) {
  ll <- -object@fit$value[length(object@fit$value)]
  attr(ll, "nobs") <- length(object@data)
  attr(ll, "df") <- length(object@fit$par)
  class(ll) <- "logLik"
  ll
})

#' Plot Method for tscmfit Class
#'
#' @param x an object of class \linkS4class{tscmfit}.
#' @param plotoption choice of plot within plottype.
#' @param plottype type of plot required.
#' @param bw logical variable specifying whether black-white options should be chosen.
#' @param klimit maximum lag value for dvinecopula2 cplots
#'
#' @export
#'
setMethod("plot", c(x = "tscmfit", y = "missing"),
          function(x, plotoption = 1L, plottype = "copula", bw = FALSE, klimit = 30) {
            switch(plottype,
                   margin = plot(new("marginfit",
                                     margin = x@margin,
                                     data = x@data,
                                     fit = x@fit), plotoption = plotoption, bw = bw),
                   copula = plot(new("tscopulafit",
                                     tscopula = x@tscopula,
                                     data = pmarg(x@margin, x@data),
                                     fit = x@fit), plotoption = plotoption, bw = bw, klimit = klimit),
                   vtransform = plot(x@tscopula@Vtransform),
                   volprofile = plot_volprofile(x, bw = bw),
                   volproxy = plot_volproxy(x, plotoption = plotoption, bw = bw))
          })


#' Plot Function for Volatility Profile Plot
#'
#' @param x an object of class \linkS4class{tscmfit}.
#' @param bw logical variable specifying whether black-white options should be chosen.
#'
#' @export
#'
plot_volprofile <- function(x, bw) {
  if (!(is(x@tscopula, "vtscopula")))
    stop("tscopula must be vtscopula")
  xvals <- seq(from = 0,
               to = max(abs(x@data)),
               length = 100)
  vpars <- x@tscopula@Vtransform@pars
  brk <- qmarg(x@margin, vpars["delta"])
  u <- pmarg(x@margin, brk - xvals)
  v <- vtrans(x@tscopula@Vtransform, u)
  yvals <- qmarg(x@margin, u + v) - brk
  plot(xvals, yvals, type = "l", ylab = expression(g[T](x)))
  colchoice <- ifelse(bw, "gray50", "red")
  abline(0, 1, col = colchoice, lty = 2)
}

#' Plot Function for Volatility Proxy Plot
#'
#' @param x an object of class \linkS4class{tscmfit}.
#' @param plotoption choice of plot.
#' @param bw logical variable specifying whether black-white options should be chosen.
#'
#' @export
#'
plot_volproxy <- function(x, plotoption, bw){
  if (!(is(x@tscopula, "vtscopula")))
    stop("tscopula must be vtscopula")
  X <- x@data
  U <- pmarg(x@margin, X)
  V <- vtrans(x@tscopula@Vtransform, U, correction = FALSE)
  colchoice <- ifelse(bw, "gray50", "red")
  switch(plotoption,
         {
           plot(strank(X),
                strank(V),
                xlab = "edf data",
                ylab = "edf vol proxy",
                col = colchoice
           )
           lines(sort(U), V[order(U)])
         },
         {
           plot(X,
                qnorm(strank(V)),
                xlab = "data",
                ylab = "std. vol proxy",
                col = colchoice
           )
           lines(sort(X), qnorm(V[order(X)]))
         })
}
